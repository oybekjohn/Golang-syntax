package main

import "fmt"

func main() {
	fmt.Println("salom dunyo!")
	x, y := 3, 5
	sum := x + y
	fmt.Println(sum)
	types()
}
