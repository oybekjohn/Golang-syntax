# golang-darslari
go dasturlash tili bo'yicha darslar (https://www.youtube.com/playlist?list=PL_WK6W0Gn1I4LW8Iur4V6GF16hnZi3-6_ dan)
