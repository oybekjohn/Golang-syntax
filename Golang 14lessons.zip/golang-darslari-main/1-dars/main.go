package main

import (
	"fmt"
)

func main() {
	fmt.Println("salom dunyo!")
}
