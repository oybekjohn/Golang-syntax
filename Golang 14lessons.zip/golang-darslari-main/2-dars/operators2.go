// solishtiruv operatorlari

package main

import "fmt"

func operators2() {
	a := 14
	b := 30

	// ‘=='(teng)
	result1 := a == b
	fmt.Println(result1)

	// ‘!='(teng emas)
	result2 := a != b
	fmt.Println(result2)

	// ‘<‘(kichik)
	result3 := a < b
	fmt.Println(result3)

	// ‘>'(katta)
	result4 := a > b
	fmt.Println(result4)

	// ‘>='(katta yoki teng)
	result5 := a >= b
	fmt.Println(result5)

	// ‘<='(kichik yoki teng)
	result6 := a <= b
	fmt.Println(result6)

}
